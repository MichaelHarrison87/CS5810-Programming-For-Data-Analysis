% CS 5810  -- Programming for data analysis 
%
%  Assignment 1 | Prof. Alberto Paccanaro
%  Deadline: October 30, 2017, at 12:00 (noon)
%
% 
% Insert BELOW your code for exercise 1, 5 and 6



%% ================== Exercise 1 ==================

% INSERT YOUR CODE FOR EXERCISE 1 HERE





%% ================== Exercise 5 ==================

% INSERT YOUR CODE FOR EXERCISE 5 HERE





%% ================== Exercise 6 ==================

% INSERT YOUR CODE FOR EXERCISE 6 HERE
